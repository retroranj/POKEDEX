package com.example.demo;
import org.boon.sort.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileReader;
import java.util.Iterator;

import java.util.List;
import java.util.LinkedList;
public class JsonParseTest {

    private static final String filePath = "pokemon.json";

    public void testboon() {

    }
    /*
    public static void main(String[] args) {
    //	Dao  dao = new Dao();
    	
    }
*/
}