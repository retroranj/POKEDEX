package com.example.demo;


import java.util.Hashtable;

import org.json.simple.parser.JSONParser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.json.simple.JSONObject;
import java.util.Set;

@RestController
public class ServerController {
    String auth = "";
    PokedexDao  dao ;
  //  UserAccount account;

    boolean token = false;
    Hashtable loginTable = new Hashtable();
    Hashtable<String, String> userPokeTable = new Hashtable();
    Hashtable<String, String> validUser;
    String line="", myline="";
    JSONParser parser;
	private static final String template = "Hello, %s!";

	public ServerController () {
		
		dao = new PokedexDao();
		validUser = new Hashtable<String, String>();
		validUser.put("test@domain.com", "maltem");
		validUser.put("test01@domain.com", "maltem01");

		Hashtable loginTable = new Hashtable();
	    Hashtable<String, String> userPokeTable = new Hashtable();
	    Hashtable<String, String> validUser;		
	}
	@RequestMapping("/pokeapp")
	public String login	() {
		
		return "Welcome to Pokedex";
	}
	
	@RequestMapping("/pokeapp/login")
	public String login	(
			@RequestParam(value = "auth" ) String auth) {
		String response = "";

		try {
			System.out.println("auth is : " + auth);
			
			String email = "";
			String password = "";

			try {
				JSONParser parser = new JSONParser();
				JSONObject jauth = (JSONObject) parser.parse(auth);
				email = jauth.get("email").toString();	
				password = jauth.get("password").toString();
			} 
			catch (Exception e){
					return "Error in Authentication Request";
			}

			if (!validUser.get(email).equals(password) ) {
				return "AUTHENTICATION FAILED ";
			}
			else { 		
				loginTable.put(email, "OK");
			}
			
			System.out.println("EMAIL from json  " +email);
		}
		catch(Exception e) {
			e.printStackTrace();
			return("LOGIN UNSUCCESSFUL, PLEASE CHECK " + e.toString());
		}
		
		System.out.println("auth= " + auth);

	    response = "Authentication success. Happy catching!! " ;		
		return response;

	}
	@RequestMapping("/pokeapp/displayUserPokemon")
	public String displayUserPokemon(
			@RequestParam(value = "email") String email) {
		String userPokemons = "";
		String response = validateLogin(email);
		if (!response.isEmpty()) return response;
		
		Set<String> keys = userPokeTable.keySet();
			for(String key: keys){
				String value = userPokeTable.get(key);
				System.out.println("Value of "+key+" is: "+userPokeTable.get(key));
				if (value.contentEquals(email)) {
					response+=dao.getUserPokemon(key);
				}
			}
		
		return response;
		
	}
	@GetMapping("/pokeapp/add")
	public String add(
		@RequestParam(value = "email") String email,
		@RequestParam(value = "name") String name) {
		String response = validateLogin(email);
		if (!response.isEmpty()) return response;
	    
	    if (userPokeTable.get(name) != null) {  
	    	response = "Someone already caught " + name;
	    }
	    else {
	    	
	    	response = "name " + name + "added";
	    	userPokeTable.put(name, email);
	    }
	    	
	    return response;
	} // end add
	@GetMapping("/pokeapp/update")
	public String update(
		@RequestParam(value = "baseAttack") String baseAttack,
		@RequestParam(value = "baseDefense") String baseDefense,
		@RequestParam(value = "baseStamina") String baseStamina,
		@RequestParam(value = "name") String name, 
		@RequestParam(value = "email") String email)  {
		String response = validateLogin(email);
		if (!response.isEmpty()) 
			return response;
		if (userPokeTable.get(name) == null) {
			return("pokemon not found");
		}		
		
		response = dao.updateStats(baseAttack, baseDefense, baseStamina, name) ;		
		
		return response;
	}
	
	@GetMapping("/pokeapp/remove")
	public String remove(
		@RequestParam(value = "email") String email,
		@RequestParam(value = "name") String name) {

		String response = validateLogin(email);
		if (!response.isEmpty()) 
			return response;
		if (userPokeTable.get(name) == null) {
			return("pokemon not found");
		}
		
    	response = "name name " + name + "remove";
    	userPokeTable.remove(name);
	    	
	    return response;
	} // end remove

	@GetMapping("/pokeapp/getAll")
	public String getAll(
		@RequestParam(value = "filter") String filter,
		@RequestParam(value = "sort") String sortKey,
		@RequestParam(value = "qty") String qty) {
		String response = ""; 
		if (qty.isEmpty() && sortKey.isEmpty() && filter.isEmpty() ) {
			response = dao.getAllRecords();
		}

		if (!qty.isEmpty()) {
			System.out.println("qty is " + qty);
			response = dao.filterByQty(Integer.parseInt(qty));
		}
		if (!filter.isEmpty()) {
			if (filter.startsWith(("name"))) {
				response = dao.filterByName(filter);
			}
			if (filter.startsWith("types") ) {
				String typename = filter.split(":")[1];
				String typevalue = filter.split(":")[2];
				response = dao.filterByType(typename + ":" + typevalue);
			}
			
			if (filter.startsWith(("stats"))) {
				String statsname = filter.split(":")[1];
				String statsvalue = filter.split(":")[2];
				response = dao.filterByStats(statsname + ":" + statsvalue);				
			}
		}

		if (!sortKey.isEmpty()) {
			String [] sortFields = sortKey.split(":");
			sortKey = sortFields[sortFields.length - 1];
			response = dao.sort(sortKey);
		}
		
		return response;
	}
	public String validateLogin(String email) {
		if(validUser.get(email) == null) { 
			return "Please Log in first";
		}
		
		if(!loginTable.get("email").equals(email)) {
			return "You are not authorized to perform this action for this user";
			
		}
		return "";

	
	} //end validateLogin
} //end ServerController

/*
 * 
http://localhost:8080/pokeapp/getAll?filter=&sort=&type=&qty=5
http://localhost:8080/pokeapp/getAll?filter=name:Bulbasaur&sort=&qty=
http://localhost:8080/pokeapp/getAll?filter=types:118&sort=&qty=5

http://localhost:8080/pokeapp/getAll?filter=stats:baseAttack:118&sort=name&qty=

 http://localhost:8080/pokeapp/add?email=test@domain.com&name=1
 http://localhost:8080/pokeapp/update?name=2&baseAttack=118&baseDefense=200&baseStamina=100


http://localhost:8080/pokeapp/getAll?filter=&sort=stats:baseAttack&qty=
http://localhost:8080/pokeapp/getAll?filter=stats:baseAttack:118&sort=&qty=5
http://localhost:8080/pokeapp/getAll?filter=baseAttack:231&sort=&qty=

 */
	
	
