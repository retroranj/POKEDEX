package com.example.demo;
import java.util.List;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class UserAccount {

	List<ArrayList> pokeList;
	
	UserAccount(List pokeList) {
		
		this.pokeList = pokeList;
	}
	
	
	public void addPokemon(int dex) {
		
	}
	

	public void updatePokemon() {
		
		
	}

	public void deletePokemon(String dex) {
		
		
		
	}

	public List get(String dex) {
		
		return this.pokeList;
	}
	
	public void display(int qty) {

	
	}
	
	public void updateStats(String dex, String [] stats) {
		
		
	}
		
}
