//-----------------------------------com.example.demo.Pokemon.java-----------------------------------

package com.example.demo;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


public class Pokemon {

@JsonProperty("dex")
public Integer dex;
@JsonProperty("name")
public String name;
@JsonProperty("animationTime")
public List<Double> animationTime = null;
@JsonProperty("height")
public Double height;
@JsonProperty("modelHeight")
public Double modelHeight;
@JsonProperty("kmBuddyDistance")
public Integer kmBuddyDistance;
@JsonProperty("weight")
public Double weight;
@JsonProperty("modelScale")
public Double modelScale;
@JsonProperty("maxCP")
public Integer maxCP;
/*TODO : Create the relevant objects and enable the code below
@JsonProperty("buddySize")
public BuddySize buddySize;
@JsonProperty("cinematicMoves")
public List<Cinematicmove> cinematicMoves = null;
@JsonProperty("quickMoves")
public List<Quickmove> quickMoves = null;
@JsonProperty("family")
public Family family;
@JsonProperty("stats")
public Stats stats;
@JsonProperty("types")
public List<Type> types = null;
@JsonProperty("encounter")
public Encounter encounter;
@JsonProperty("camera")
public Camera camera;
@JsonProperty("evolution")
public Evolution evolution;
@JsonProperty("id")
public String id;
@JsonProperty("forms")
public List<Object> forms = null;
*/
}
/*

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"id",
"name"
})

package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;





package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"cylinderRadius",
"diskRadius",
"shoulderModeScale"
})
public class Camera {

@JsonProperty("cylinderRadius")
public Double cylinderRadius;
@JsonProperty("diskRadius")
public Double diskRadius;
@JsonProperty("shoulderModeScale")
public Double shoulderModeScale;

}
-----------------------------------com.example.demo.Cinematicmove.java-----------------------------------

package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"name",
"id"
})
public class Cinematicmove {

@JsonProperty("name")
public String name;
@JsonProperty("id")
public String id;

}
-----------------------------------com.example.demo.CostToEvolve.java-----------------------------------

package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"candyCost"
})
public class CostToEvolve {

@JsonProperty("candyCost")
public Integer candyCost;

}
-----------------------------------com.example.demo.CostToEvolve_.java-----------------------------------

package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"candyCost"
})
public class CostToEvolve_ {

@JsonProperty("candyCost")
public Integer candyCost;

}
-----------------------------------com.example.demo.Encounter.java-----------------------------------

package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"attackProbability",
"attackTimer",
"baseFleeRate",
"baseCaptureRate",
"cameraDistance",
"collisionRadius",
"dodgeDistance",
"dodgeProbability",
"jumpTime",
"maxPokemonActionFrequency",
"minPokemonActionFrequency",
"movementType",
"gender"
})
public class Encounter {

@JsonProperty("attackProbability")
public Double attackProbability;
@JsonProperty("attackTimer")
public Integer attackTimer;
@JsonProperty("baseFleeRate")
public Double baseFleeRate;
@JsonProperty("baseCaptureRate")
public Double baseCaptureRate;
@JsonProperty("cameraDistance")
public Double cameraDistance;
@JsonProperty("collisionRadius")
public Double collisionRadius;
@JsonProperty("dodgeDistance")
public Integer dodgeDistance;
@JsonProperty("dodgeProbability")
public Double dodgeProbability;
@JsonProperty("jumpTime")
public Double jumpTime;
@JsonProperty("maxPokemonActionFrequency")
public Double maxPokemonActionFrequency;
@JsonProperty("minPokemonActionFrequency")
public Double minPokemonActionFrequency;
@JsonProperty("movementType")
public MovementType movementType;
@JsonProperty("gender")
public Gender gender;

}
-----------------------------------com.example.demo.Evolution.java-----------------------------------

package com.example.demo;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"futureBranches"
})
public class Evolution {

@JsonProperty("futureBranches")
public List<FutureBranch> futureBranches = null;

}
-----------------------------------com.example.demo.Family.java-----------------------------------

package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"id",
"name"
})
public class Family {

@JsonProperty("id")
public String id;
@JsonProperty("name")
public String name;

}
-----------------------------------com.example.demo.FutureBranch.java-----------------------------------

package com.example.demo;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"name",
"id",
"futureBranches",
"costToEvolve"
})
public class FutureBranch {

@JsonProperty("name")
public String name;
@JsonProperty("id")
public String id;
@JsonProperty("futureBranches")
public List<FutureBranch_> futureBranches = null;
@JsonProperty("costToEvolve")
public CostToEvolve_ costToEvolve;

}
-----------------------------------com.example.demo.FutureBranch_.java-----------------------------------

package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"name",
"id",
"costToEvolve"
})
public class FutureBranch_ {

@JsonProperty("name")
public String name;
@JsonProperty("id")
public String id;
@JsonProperty("costToEvolve")
public CostToEvolve costToEvolve;

}
-----------------------------------com.example.demo.Gender.java-----------------------------------

package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"malePercent",
"femalePercent"
})
public class Gender {

@JsonProperty("malePercent")
public Double malePercent;
@JsonProperty("femalePercent")
public Double femalePercent;

}
-----------------------------------com.example.demo.MovementType.java-----------------------------------

package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"name",
"id"
})
public class MovementType {

@JsonProperty("name")
public String name;
@JsonProperty("id")
public String id;

}

-----------------------------------com.example.demo.Quickmove.java-----------------------------------

package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"name",
"id"
})
public class Quickmove {

@JsonProperty("name")
public String name;
@JsonProperty("id")
public String id;

}
-----------------------------------com.example.demo.Stats.java-----------------------------------

package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"baseAttack",
"baseDefense",
"baseStamina"
})
public class Stats {

@JsonProperty("baseAttack")
public Integer baseAttack;
@JsonProperty("baseDefense")
public Integer baseDefense;
@JsonProperty("baseStamina")
public Integer baseStamina;

}
-----------------------------------com.example.demo.Type.java-----------------------------------

package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"id",
"name"
})
public class Type {

@JsonProperty("id")
public String id;
@JsonProperty("name")
public String name;

}
*/